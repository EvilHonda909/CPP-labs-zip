#include "Interpreter.h"
#include <iostream>

int main()
{
	setlocale(LC_CTYPE, "Russian");
	Interpreter i(std::cin, std::cout);
}