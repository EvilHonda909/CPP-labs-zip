//
//  Language.cpp
//  Language
//
//  Created by macintosh on 28/08/2021.
//

#include "Language.hpp"


Language::Language(std::string name, int lettersCount, std::string family): name(name), lettersCount(lettersCount), family(family) {}

std::string Language::toString() const {
    return "Name: " + name + "\nFamily: " + family + "\nLetters quantity: " + std::to_string(lettersCount);
}

std::string Language::getName() const {
    return name;
}
int Language::getLettersCount() const {
    return lettersCount;
}
std::string Language::getFamily() const {
    return family;
}

bool Language::operator==(const Language &other) {
    return name == other.name && lettersCount == other.lettersCount && family == other.family;
}

bool Language::operator==(const std::string &other) {
    return name == other;
}
