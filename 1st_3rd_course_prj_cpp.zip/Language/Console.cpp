//
//  Console.cpp
//  Language
//
//  Created by macintosh on 28/08/2021.
//

#include <vector>
#include <numeric>
#include <ostream>
#include <optional>
#include <algorithm>
#include "Console.hpp"

const std::vector<MenuItems> allItems = {
    ADD,
    REMOVE,
    SHOW_COLLECTION,
    SORT_BY_NAME,
    MIN_LETTERS_LANGUAGE,
    ALL_FAMILIES,
    ALL_LETTERS,
    FIND_WITH_LETTERS_COUNT,
    FIND_BY_NAME,
    EXIT
};

const std::vector<MenuItems> emptyCollectionItems = {
    ADD,
    EXIT
};

std::string decodedMenuItem(const MenuItems& item) {
    switch (item) {
        case ADD:
            return "1 - add language to languages collection";
        case REMOVE:
            return "2 - remove a language from languages collection using its name";
        case SHOW_COLLECTION:
            return "3 - show language collection";
        case SORT_BY_NAME:
            return "4 - sort language collection by name in ascending order";
        case MIN_LETTERS_LANGUAGE:
            return "5 - show the language with minimum letters";
        case ALL_FAMILIES:
            return "6 - show all families contained by language collection";
        case ALL_LETTERS:
            return "7 - show quantity of all letters included in all languages of collection";
        case FIND_WITH_LETTERS_COUNT:
            return "8 - show languages having more than defined amount of letters";
        case FIND_BY_NAME:
            return "9 - show language having defined name";
        case EXIT:
            return "10 - finish";
    }
}

std::string Console::getMenuItems() {
    std::vector<MenuItems> menuItems = languages.isEmpty() ? emptyCollectionItems : allItems;
    return std::accumulate(menuItems.begin(), menuItems.end(), std::string(), [](const std::string& items, const MenuItems& menuItem) {
        return items + "\n" + decodedMenuItem(menuItem);
    });
}

std::optional<int> decodeInt(std::string buffer) {
    try {
        return std::make_optional(std::stoi(buffer));
    } catch (std::invalid_argument) {
        return std::nullopt;
    }
}

void trim(std::string& buffer) {
    // ltrim
    buffer.erase(buffer.begin(), std::find_if(buffer.begin(), buffer.end(), [](unsigned char ch) {
        return !std::isspace(ch);
    }));
    // rtrim
    buffer.erase(std::find_if(buffer.rbegin(), buffer.rend(), [](unsigned char ch) {
        return !std::isspace(ch);
    }).base(), buffer.end());
}

std::optional<std::string> handleStringInput(std::string info) {
    std::string buffer;
    std::cout << info << std::endl;
    std::cin >> buffer;
    trim(buffer);
    if (buffer.size() == 0) {
        return std::nullopt;
    } else {
        return std::make_optional(buffer);
    }
}

std::optional<std::vector<std::string>> handleAddInput() {
    std::vector<std::string> allInput;
    std::optional<std::string> buffer;
    
    buffer = handleStringInput("Type language name");
    if (buffer != std::nullopt) {
        allInput.push_back(buffer.value());
    } else {
        return std::nullopt;
    }
    
    std::cout << "Type count of letters" << std::endl;
    std::cin >> buffer.value();
    if (decodeInt(buffer.value()) == std::nullopt) {
        return std::nullopt;
    } else {
        allInput.push_back(buffer.value());
    }
    
    buffer = handleStringInput("Type family name");
    if (buffer != std::nullopt) {
        allInput.push_back(buffer.value());
    } else {
        return std::nullopt;
    }
    
    return allInput;
}

std::optional<std::vector<std::string>> handleRemoveInput() {
    std::vector<std::string> allInput;
    std::optional<std::string> buffer;
    
    buffer = handleStringInput("Type language name you would like to remove");
    if (buffer != std::nullopt) {
        allInput.push_back(buffer.value());
    } else {
        return std::nullopt;
    }
    
    return allInput;
}

std::optional<std::vector<std::string>> handleSearchInput() {
    std::vector<std::string> allInput;
    std::string buffer;
    
    std::cout << "Type count of letters that will be served as minimum barrier" << std::endl;
    std::cin >> buffer;
    if (decodeInt(buffer) == std::nullopt) {
        return std::nullopt;
    } else {
        allInput.push_back(buffer);
    }
    
    return std::make_optional(allInput);
}

std::optional<std::vector<std::string>> handleLanguageNameSearchInput() {
    std::vector<std::string> allInput;
    std::optional<std::string> buffer;
    
    buffer = handleStringInput("Type language name you would like to look for");
    if (buffer != std::nullopt) {
        allInput.push_back(buffer.value());
    } else {
        return std::nullopt;
    }
    
    return allInput;
}


std::optional<std::vector<std::string>> Console::handleArgumentsInput() {
    std::optional<std::vector<std::string>> allInput;
    std::string buffer;
    
    switch (selectedMenuItem) {
        case ADD:
            return handleAddInput();
        case REMOVE:
            return handleRemoveInput();
        case FIND_WITH_LETTERS_COUNT:
            return handleSearchInput();
        case FIND_BY_NAME:
            return handleLanguageNameSearchInput();
        default:
            std::cout << "Wait..." << std::endl;
            return std::make_optional(std::vector<std::string>{});
    }
}

std::optional<MenuItems> handleMenuItemInput(std::string input) {
    std::optional<int> menuItemNumber = decodeInt(input);
    if (menuItemNumber == std::nullopt) {
        return std::nullopt;
    } else if (menuItemNumber.value() - 1 >= 0 && menuItemNumber.value() - 1 <= 9) {
        return std::make_optional(static_cast<MenuItems>(menuItemNumber.value() - 1));
    } else {
        return std::nullopt;
    }
}

std::string formatLanguages(std::vector<Language> languages) {
    return std::accumulate(languages.begin(), languages.end(), std::string(), [](const std::string& output, const Language& language) {
        std::string languageToString = "Name: " + language.getName() + "\n";
        languageToString += "Family: " + language.getFamily() + "\n";
        languageToString += "Letters quantity: " + std::to_string(language.getLettersCount());
        return output + languageToString + "\n";
    });
}

std::string Console::calculateInput() {
    switch (selectedMenuItem) {
        case ADD: {
            Language lang = Language(arguments[0], std::stoi(arguments[1]), arguments[2]);
            languages.add(lang);
            return "Your language were added in case it didn't exist in collection before";
        }
        case REMOVE:
            languages.removeBy(arguments[0]);
            return "Language with selected name was removed in case it existed in collection before";
        case FIND_BY_NAME: {
            std::optional<Language> targetLanguage = languages.findBy(arguments[0]);
            if (targetLanguage == std::nullopt) {
                return "Specified name isn't represented in collection";
            } else {
                return formatLanguages({targetLanguage.value()});
            }
        }
        case SHOW_COLLECTION: {
            return formatLanguages(languages.getLanguages());
        }
        case FIND_WITH_LETTERS_COUNT: {
            std::vector<Language> targetLanguages = languages.findWithMoreLettersThan(std::stoi(arguments[0]));
            if (targetLanguages.size() == 0) {
                return "We didn't find any language which alphabet satisfies your condition";
            } else {
                return formatLanguages(targetLanguages);
            }
        }
        case ALL_FAMILIES: {
            std::vector<std::string> families = languages.accumulateFamilies();
            return std::accumulate(families.begin(), families.end(), std::string{"Families: "}, [](const std::string& output, const std::string& family) {
                return output + family + ", ";
            });
        }
        case ALL_LETTERS: {
            int lettersCount = languages.calculateAllLetters();
            return "Number of letters: " + std::to_string(lettersCount);
        }
        case SORT_BY_NAME: {
            languages.sortByName();
            return "Collection has been sorted";
        }
        case MIN_LETTERS_LANGUAGE: {
            std::optional<int> minLettersCount = languages.getMinLettersCount();
            if (minLettersCount == std::nullopt) {
                return "It seems that your collection is empty";
            } else {
                return "Minimum letters: " + std::to_string(minLettersCount.value());
            }
        }
        case EXIT:
            return "The program will be finished";
    }
}

void Console::next() {
    switch (state) {
        case IDLE: {
            std::cout << "Hi, you have a chance to work with language collection";
            state = WAIT_FOR_MENU_ITEM;
            break;
        }
        case WAIT_FOR_MENU_ITEM: {
            std::cout << getMenuItems() << std::endl;
            std::cout << "Please, choose an interested menu item and type corresponding number" << std::endl << "Number: ";
            std::string menuItemNumber;
            std::cin >> menuItemNumber;
            std::optional<MenuItems> menuItem = handleMenuItemInput(menuItemNumber);
            if (menuItem == std::nullopt) {
                state = INPUT_ERROR;
            } else {
                selectedMenuItem = menuItem.value();
                if (selectedMenuItem == EXIT) {
                    state = END;
                } else {
                    state = WAIT_FOR_ARG;
                }
            }
            break;
        }
        case WAIT_FOR_ARG: {
            std::optional<std::vector<std::string>> input = handleArgumentsInput();
            if (input == std::nullopt) {
                state = INPUT_ERROR;
            } else {
                arguments = input.value();
                state = CALCULATIONS;
            }
            break;
        }
        case CALCULATIONS: {
            std::cout << calculateInput() << std::endl;
            state = WAIT_FOR_MENU_ITEM;
            break;
        }
        case INPUT_ERROR: {
            std::cout << "You made a mistake, you will be return to the menu" << std::endl;
            state = WAIT_FOR_MENU_ITEM;
            break;
        }
        case END:
            std::cout << "Bye.." << std::endl;
            break;
    }
}

bool Console::hasFinished() {
    return state == END;
}
