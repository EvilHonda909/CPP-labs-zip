//
//  LanguageCollection.hpp
//  Language
//
//  Created by macintosh on 28/08/2021.
//

#ifndef LanguageCollection_hpp
#define LanguageCollection_hpp

#include <string>
#include <vector>
#include <optional>
#include "Language.hpp"

class LanguageCollection {
private:
    std::vector<Language> storage = {};
public:
    std::vector<Language> getLanguages();
    bool isEmpty();
    void add(Language lang);
    void removeBy(std::string name);
    void sortByName();
    std::optional<int> getMinLettersCount();
    std::vector<std::string> accumulateFamilies();
    int calculateAllLetters();
    std::vector<Language> findWithMoreLettersThan(int lettersCount);
    std::optional<Language> findBy(std::string name);
};

#endif /* LanguageCollection_hpp */
