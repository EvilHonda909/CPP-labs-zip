//
//  main.cpp
//  Language
//
//  Created by macintosh on 28/08/2021.
//

#include <stdio.h>
#include <iostream>
#include <string>
#include "Console.hpp"

int main() {
    Console console = Console();
    while (!console.hasFinished()) {
        console.next();
    }
    return 0;
}
