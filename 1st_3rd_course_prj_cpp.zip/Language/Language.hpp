//
//  Language.hpp
//  Language
//
//  Created by macintosh on 28/08/2021.
//

#ifndef Language_hpp
#define Language_hpp

#include <string>

class Language {
private:
    std::string name;
    int lettersCount;
    std::string family;
public:
    Language(std::string name, int lettersCount, std::string family);
    std::string toString() const;
    
    std::string getName() const;
    int getLettersCount() const;
    std::string getFamily() const;
    
    bool operator==(const Language &other);
    bool operator==(const std::string &other);
};

#endif /* Language_hpp */
