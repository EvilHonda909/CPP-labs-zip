//
//  LanguageCollection.cpp
//  Language
//
//  Created by macintosh on 28/08/2021.
//

#include <algorithm>
#include <iterator>
#include <functional>
#include <numeric>
#include <set>
#include "LanguageCollection.hpp"

void LanguageCollection::add(Language lang) {
    if (std::find(storage.begin(), storage.end(), lang) == storage.end()) {
        storage.push_back(lang);
    }
}

void LanguageCollection::removeBy(std::string name) {
    storage.erase(std::remove(storage.begin(), storage.end(), name), storage.end());
}

std::vector<Language> LanguageCollection::getLanguages() {
    return storage;
}

bool LanguageCollection::isEmpty() {
    return storage.size() == 0;
}

bool comparator(const Language& i, const Language& j) {
    return i.getName() < j.getName();
}
    
void LanguageCollection::sortByName() {
    std::sort(storage.begin(), storage.end(), comparator);
}

std::vector<Language> LanguageCollection::findWithMoreLettersThan(int lettersCount) {
    return std::accumulate(storage.begin(), storage.end(), std::vector<Language>(), [lettersCount](std::vector<Language>& languages, const Language& lang) {
        if (lang.getLettersCount() > lettersCount) {
            languages.push_back(lang);
        }
        return languages;
    });
}

std::optional<Language> LanguageCollection::findBy(std::string name) {
    std::vector<Language>::iterator iter = std::find(storage.begin(), storage.end(), name);
    if (iter != storage.end()) {
        return std::optional<Language>(*iter);
    } else {
        return std::nullopt;
    }
}

bool min(const Language& i, const Language& j) {
    return i.getLettersCount() < j.getLettersCount();
}

std::optional<int> LanguageCollection::getMinLettersCount() {
    std::vector<Language>::iterator iter = std::min_element(storage.begin(), storage.end(), min);
    if (iter != storage.end()) {
        return std::optional<int>(iter->getLettersCount());
    } else {
        return std::nullopt;
    }
}

std::string transformer(const Language& lang) {
    return lang.getFamily();
}

std::vector<std::string> LanguageCollection::accumulateFamilies() {
    std::set<std::string> families;
    std::transform(storage.begin(), storage.end(), std::inserter(families, families.end()),
        transformer);
    return std::vector<std::string> (families.begin(), families.end());
}

int lettetsCountAccumulator(const int& lettersCount, const Language& lang) {
    return lettersCount + lang.getLettersCount();
}

int LanguageCollection::calculateAllLetters() {
    return std::accumulate(storage.begin(), storage.end(), 0, lettetsCountAccumulator);
}
