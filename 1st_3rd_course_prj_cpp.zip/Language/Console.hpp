//
//  Console.hpp
//  Language
//
//  Created by macintosh on 28/08/2021.
//

#ifndef Console_hpp
#define Console_hpp

#include <iostream>
#include <string>
#include "LanguageCollection.hpp"

enum MenuItems {
    ADD,
    REMOVE,
    SHOW_COLLECTION,
    SORT_BY_NAME,
    MIN_LETTERS_LANGUAGE,
    ALL_FAMILIES,
    ALL_LETTERS,
    FIND_WITH_LETTERS_COUNT,
    FIND_BY_NAME,
    EXIT
};

enum ConsoleState {
    IDLE,
    WAIT_FOR_MENU_ITEM,
    WAIT_FOR_ARG,
    CALCULATIONS,
    INPUT_ERROR,
    END
};

class Console {
private:
    LanguageCollection languages = LanguageCollection();
    std::vector<std::string> arguments;
    ConsoleState state = IDLE;
    MenuItems selectedMenuItem;
    
    std::string getMenuItems();
    std::optional<std::vector<std::string>> handleArgumentsInput();
    std::string calculateInput();
public:
    void next();
    bool hasFinished();
};

#endif /* Console_hpp */
