//
//  main.cpp
//  ComplexNumberClass
//
//  Created by Egor Mikhailov on 21.04.2021.
//

#include "Console.hpp"

using namespace std;

int main() {
    auto console = Console();
    console.start();

    return 0;
}
